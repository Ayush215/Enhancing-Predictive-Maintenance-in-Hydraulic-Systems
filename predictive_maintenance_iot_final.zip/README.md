# Predictive Maintenance Using IoT Sensor Data

This project explores predictive maintenance using machine learning and deep learning on hydraulic systems IoT sensor data.

## 📌 Coursework Summary

- **Coursework 1**: Literature review on predictive maintenance techniques.
- **Coursework 2**: Implementation of a hybrid LSTM-Random Forest model using the UCI Hydraulic Systems dataset.

## 🔍 Key Features

- Time-series sensor data processing
- Noise reduction (Wavelet Transform)
- SMOTE for class imbalance
## 📓 Jupyter Notebook

- `A00045830_AYUSH_BHARATBHAI_PATEL_COURSWORK_2_CODE.ipynb`: Contains model training, evaluation, and interpretability using SHAP.

- PCA for dimensionality reduction
- Hybrid model (LSTM + RF)
- Interpretability with SHAP

## 📁 Structure

- `/docs`: Final submitted coursework PDFs
- `/src`: Source code for data processing and model training
- `/notebooks`: Exploratory data analysis and visualizations
- `/data`: Dataset links and data instructions

## 📊 Dataset

[UCI Condition Monitoring of Hydraulic Systems Dataset](https://archive.ics.uci.edu/dataset/447/condition+monitoring+of+hydraulic+systems)

## 🚀 Getting Started

```bash
pip install -r requirements.txt
python src/models/hybrid_lstm_rf.py
```

## 📄 License

For academic use only.
